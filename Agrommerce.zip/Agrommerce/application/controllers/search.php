<?php
class search extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
            $this->load->helper('form');
    }

    public function index()
    {
        $this->load->view('home');
    }

    public function categories()
    {
        // Retrieve the posted search term.
        $search = $this->input->post('search');

        // Use a model to retrieve the results.
        $data['results'] = $this->Main_Model->search_items($search);
        // Pass the results to the view.
             $this->load->view('templates/header');
                $this->load->view('pages/search',$data);
             $this->load->view('templates/footer');
    }

}
?>