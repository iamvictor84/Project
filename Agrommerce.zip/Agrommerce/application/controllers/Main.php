<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
        class Main extends CI_Controller
        {
            public function __construct(){
                 parent::__construct();
                    $this->load->helper('url');
                    $this->load->library('user_agent');
                    $this->load->library('form_validation');
                    $this->load->library('pagination');
                    $this->load->helper('form');
            }
        
            public function views($page = 'home'){
             if(!file_exists(APPPATH.'views/pages/'.$page.'.php'))
                { 
                    //Page doesn't exist
                        show_404();
                }
                
                #########################################################################
                //array for different pages
                $data['grains_legumes'] = $this->Main_Model->fetch_grain_legumes();
                ########################################################################## 
                

                 $data['title'] = ucfirst($page);
                        $this->load->view('templates/header');
                        $this->load->view('pages/'.$page,$data);
                        $this->load->view('templates/footer');         
            }
            
           public function search_items(){
                $search = $this->input->post('search');
                //using a model to retrieve the results;
                $data['results'] = $this->Main_Model->search_items($search);
                    $this->load->view('templates/header');
                    $this->load->view('pages/search',$data);
                    $this->load->view('templates/footer');
            }
            
            public function subscribe_users(){
            $this->form_validation->set_rules('email','Email Address','trim|required|valid_email|max_length[500]|min_length[5]|strip_tags',
                array(
                        'required' => 'You must fill in the email address!',
                        'min_length' => 'That email looks invalid!',
                        'max_length' => 'That email is exceeds the maximum length',
                    )                           
            );
                if($this->form_validation->run() == FALSE){
                    redirect('home');
                }else{
                     if($this->Main_Model->subscribedUsers()){
                            redirect('home');
                        }
                    }
                }
            
            public function track_order(){
                $this->form_validation->set_rules('email','Email Address','trim|required|max_length[1000]|min_length[5]|strip_tags');
                
                 $this->form_validation->set_rules('PID','Package ID','trim|required|max_length[10]|min_length[10]|strip_tags');
                
                    if($this->form_validation->run() == FALSE){
                        $this->session->set_flashdata('error_input','<p class = "required"> *The data you entered is invalid. </p>');
                            redirect('order');
                    }else{
                            $email = $this->input->post('email');
                            $PID = $this->input->post('PID');
                                if($this->Main_Model->check_order($email,$PID)){
                                    redirect('questions');
                                }else{
                                    $this->session->set_flashdata('no_record','<p class = "required"> *Please cross-check the package details. </p>');
                                        redirect('order');
                                }
            }
            }
            
            }

       
?>