<?php
    class Main_Model extends CI_Model{
        public function register_user(){
            $encrypt_password = md5($this->input->post('password'));
                $data = array(
                'userEmail' => $this->input->post('email'),
                'userPassword' => $encrypt_password,
                'createdDate' => date("jS F Y"),
                'createdTime' => date('G:i A'),
                'userDevice' => $this->agent->platform()
            );
            $insert = $this->db->insert('userData',$data);
            return $insert;
        }
        
         public function search_items($search = 'default'){
            $this->db->select('*');
             $this->db->from('grains_legumes');
             $this->db->like('itemName',$search);
                $query = $this->db->get();
                    return $query->result();
        }
        
         public function get_roots_tubers(){
            
        }
          
         public function subscribedUsers(){
             if ($this->agent->is_browser()){
                    $agent = $this->agent->browser().' '.$this->agent->version();
                }elseif($this->agent->is_robot()){
                        $agent = $this->agent->robot();
                }elseif ($this->agent->is_mobile()){
                    $agent = $this->agent->mobile();
                }else{
                    $agent = 'Unidentified User Agent';
                }
                
                $data = array(
                'userEmail' => $this->input->post('email'),
                'userBrowser' =>  $agent,
                'userDevice' =>  $this->agent->platform(),
                'subTime' => date('G:i A'),
                'subDate' => date("jS F Y"),
                //'ip' => getenv('REMOTE_ADDR')
            );
            $insert = $this->db->insert('subscribedUsers',$data);
                return $insert;
        }
        
        public function fetch_grain_legumes(){
            $query = $this->db->query('SELECT * FROM grains_legumes ORDER BY id DESC');
                return $query->result();
        }
        
        public function check_order($email,$PID){
            $this->db->where('userEmail',$email);
            $this->db->where('packageID',$PID);
                $result = $this->db->get('userOrders');
                    if($result->num_rows() == 1){
                        return $result->row(0)->id;
                    }else{
                        return false;
                    }
        }
        
        
       
       
            
        }
?>