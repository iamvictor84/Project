<div class="pag-nav">
			<ul class="p-list">
				<li><a href="<?php echo base_url(); ?>home">Home</a></li> &nbsp;&nbsp;/&nbsp;
				<li class="act">&nbsp;Orders</li>
			</ul>
		</div>

		<!-- start account -->
		<div class="login-page">
            <div class="dreamcrub">
			   <div class="account_grid">
			   <div class="col-md-6 login-left">
			  	 <h3>NOTICE</h3>
				 <p>By tracking your order you can be able to check the status of your due delivery, please check your email address for your unique Package ID. When you choose to customzie an order you will be offered to state the particular item you require.</p>
				 <a class="acount-btn" href="<?php echo base_url(); ?>customize">Customize an order</a>
			   </div>
			   <div class="col-md-6 login-right">
			  	<h3>TRACK YOUR ORDER</h3>
				<p>Fill out the following check your order</p>
				<?php echo form_open('Main/track_order'); ?>
				  <div>
                        <?php 
                            if($this->session->flashdata('error_input')){
                                echo $this->session->flashdata('error_input');
                            }else if($this->session->flashdata('no_record')){
                                 echo $this->session->flashdata('no_record'); 
                            }else{
                                echo '<p class = "required"> * Fill in all fields </p> ';
                            }
                        ?>
                      <span>Email Address*</span>
					<input type="text" name = "email" placeholder="Type your email address here..." required> 
				  </div>
				  <div>
					<span>Package ID*</span>
					<input type="text" name = "PID" placeholder="Package ID " required> 
				  </div>
				        <input type="submit" value="Check">
			    <?php echo form_close(); ?>
			   </div>	
			   <div class="clearfix"> </div>
			 </div>
		   </div>
</div>
	</div>