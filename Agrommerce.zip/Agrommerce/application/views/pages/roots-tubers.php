<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<div class="main_bg">
	<div class="main">	   		           	         
		<div class="latest-products">
		<h2 class="style top">Roots & Tubers</h2>
		<!-- start grids_of_3 -->
		<div class="grids_of_3">
			<div class="grid1_of_3">
				<a href="<?php echo base_url(); ?>item">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;4,000 </b> Per Sack
                            <br/><br/>
                            <form action = "<?php echo base_url(); ?>item" method = "POST">
                                <input type = "hidden" name = "itemName" value = "sweet potato"/>
                                <input type = "hidden" name = "itemPrice" value = "4000"/>
                                <input type = "hidden" name = "itemMeasurement" value = "sack"/>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
                <span class="b_btm"></span>
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
            <div class="grid1_of_3">
				<a href="single.html">
					<img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:200px"/>
                </a>
					   <h3>Sweet Potato</h3>
					<div class="price1">
						<h4> <b>&#8358;12,000 </b> Per Basket
                                <br/><br/>
                            <form>
                                <button type = "submit" name = "purchase" class = "btn"><span>ADD TO ORDER</span></button>
                            </form>
                        </h4>
					</div>
					<span class="b_btm"></span>
				
			</div>
			<div class="clearfix"></div>
		</div>

		<!-- end grids_of_3 -->
	</div>
	<div class="sub-cate">
				<div class=" top-nav rsidebar span_1_of_left">
					<h3 class="cate">More...</h3>
		 <ul class="menu">
		<li class="item1"><a href="#">Related <img class="arrow-img" src="images/arrow1.png" alt=""/> </a>
			<ul class="cute">
				<li class="subitem1"><a href="products.html">Cute Kittens </a></li>
				<li class="subitem2"><a href="products.html">Strange Stuff </a></li>
				<li class="subitem3"><a href="products.html">Automatic Fails </a></li>
			</ul>
		</li>
		
				<li>
			<ul class="kid-menu">
				<li><a href="products.html">Tempus pretium</a></li>
				<li ><a href="products.html">Help</a></li>
				<li ><a href="products.html">How to order?</a></li>
			</ul>
		</li>
	</ul>
					</div>
				<!--initiate accordion-->
		<script type="text/javascript">
			$(function() {
			    var menu_ul = $('.menu > li > ul'),
			           menu_a  = $('.menu > li > a');
			    menu_ul.hide();
			    menu_a.click(function(e) {
			        e.preventDefault();
			        if(!$(this).hasClass('active')) {
			            menu_a.removeClass('active');
			            menu_ul.filter(':visible').slideUp('normal');
			            $(this).addClass('active').next().stop(true,true).slideDown('normal');
			        } else {
			            $(this).removeClass('active');
			            $(this).next().stop(true,true).slideUp('normal');
			        }
			    });
			
			});
		</script>
					<div class=" chain-grid menu-chain text-center">
	   		     		<a href="products.html"><img class="img-responsive chain" src="<?php echo base_url(); ?>images/carrot.jpg" alt=" " /></a>	   		     		
	   		     		<div class="grid-chain-bottom chain-watch">
		   		     		<span class="actual dolor-left-grid">&#8358; 6000</span>
		   		     		<span class="reducedfrom">&#8358; 9000</span>  
		   		     		<h6>Eastern Carrots</h6>  		     			   		     										
	   		     		</div>
	   		     	</div>
	   		     	 <a class="view-all all-product" href="products.html">View More...<span> </span></a> 	
					  <div class="clearfix"> </div>
			</div>
	 <div class="clearfix"> </div>
</div>
</div>
	