<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<div class="wrapper">
    <div class="header header-filter" style="background-image: url('<?php echo base_url();?>images/banner.jpg'); background-size: cover; background-position: top center;">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">
						<div class="card card-signup">
							<?php echo form_open('Main/register_user'); ?>
								<div class="header header-success text-center">
									<h4>Register</h4>
									<div class="social-line">
										<a href="#" class="btn btn-simple btn-just-icon">
											<i class="fa fa-facebook-square"></i>
										</a>
										<a href="#" class="btn btn-simple btn-just-icon">
											<i class="fa fa-twitter"></i>
										</a>
										<a href="#" class="btn btn-simple btn-just-icon">
											<i class="fa fa-google-plus"></i>
										</a>
									</div>
								</div>
							     
                                <?php echo $this->session->flashdata('errors'); ?>
                                    
								<div class="content">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="material-icons">mail_outline</i>
										</span>
										<input type="email" class="form-control" placeholder="Email..." name = "email" required>
									</div>

									<div class="input-group">
										<span class="input-group-addon">
											<i class="material-icons">lock_open</i>
										</span>
										<input type="password" placeholder="Password..." class="form-control" name = "password" required/>
									</div>

									<div class="input-group">
										<span class="input-group-addon">
											<i class="material-icons">lock_outline</i>
										</span>
										<input type="password" placeholder="Re-type password..." class="form-control" name = "password2" required/>
									</div>

									

									<div class="checkbox">
										<label>
											<input type="checkbox" name="optionsCheckboxes" checked>
											     <a href = "#">Accept Terms & Conditions</a>
										</label>
									</div> 
								</div>
								<div class="footer text-center">
									<button type = "submit"  class="btn  btn-primary" name = "register">Get Started</button>
								</div>
							<?php echo form_close(); ?>
						</div>
					</div>
				</div>
			</div>