<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
        if($this->session->userdata('logged_in') == TRUE){
?>
    <div class="wrapper">
		<div class="header header-filter" style="background-image: url('<?php echo base_url(); ?>images/banner.jpg');"></div>

		<div class="main main-raised">
			<div class="profile-content">
	            <div class="container">
	                <div class="row">
	                    <div class="profile">
	                        <div class="avatar">
	                            <img src="<?php echo base_url(); ?>images/default-avatar.png" alt="Circle Image" class="img-circle img-responsive img-raised">
	                        </div>
	                        
	                    </div>
	                </div>
                    
				<div class="row">
					<div class="col-lg-12">
						<div class="title">
							<h3><?php echo ucfirst($this->session->userdata('email')); ?></h3>
						</div>

						<div class="card card-nav-tabs">
							<div class="header header-success">
								<div class="nav-tabs-navigation">
									<div class="nav-tabs-wrapper">
										<ul class="nav nav-tabs" data-tabs="tabs">
											<li class="active">
												<a href="#profile" data-toggle="tab">
													<i class="material-icons">account_circle</i>
													Profile 
                                                        <?php 
                                                            if($_SESSION['link'] == 'valid'){
                                                                //echo '<span class="badge bg-info"></span>';
                                                                }else{
                                                                    echo '<span class = "label label-danger">Important</span>';
                                                            }
                                                        ?>
												</a>
											</li>
											<li>
												<a href="#orders" data-toggle="tab">
													<i class="material-icons">motorcycle</i>
													   Orders
												</a>
                                            </li>
                                            <li>
												<a href="#edit" data-toggle="tab">
													<i class="material-icons">create</i>
													   Edit Profile
												</a>
											</li>
                                            <li>
												<a href="<?php if($_SESSION['link'] == 'valid'){echo  '#deleteModal';}else{echo '#';} ?>" data-toggle="modal">
													<i class="material-icons">settings</i>
													   Delete Account
												</a>
											</li>
                                           
										</ul>
									</div>
								</div>
							</div>
                                <?php 
                                        if(isset($Profile)){
                                            foreach($Profile as $profile){
                                                //echo $profile->fName; 
                                        }
                                        
                                    }
                                ?>
							<div class="content">
								<div class="tab-content text-center">
									<div class="tab-pane active" id="profile">
                                        <?php 
                                            if($_SESSION['link'] == 'valid'){
                                                echo '<h4>Profile Updated</h4>'; 
                                            }else{
                                                echo '<h4>Please update your profile details</h4>';
                                            }
                                        ?>
										
                                        
                                <?php echo $this->session->flashdata('not_updated'); ?>
                                <?php echo $this->session->flashdata('updated'); ?>
                                <?php echo form_open('Main/update_profile'); ?>
                                        
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">face</i>
										      </span>
                                                
										          <input type="text" class="form-control" 
                                                        placeholder="<?php if(empty($profile->fName)){echo 'First Name';}else{ echo  $profile->fName;} ?>" name = "fname" required>
									       </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">face</i>
										      </span>
										          <input type="text" class="form-control" placeholder="<?php if(empty($profile->lName)){echo 'Last Name';}else{ echo  $profile->lName;} ?>" name = "lname" required>
									       </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">phone</i>
										      </span>
										          <input type="text" class="form-control" placeholder="<?php if(empty($profile->Phone)){echo 'Phone Number';}else{ echo  $profile->Phone;} ?>" name = "phone" required>
									       </div>
                                        </div>
                                        <div class = "col-lg-6">
                                            <div class="form-group">
                                                <?php 
                                                    if(empty($profile->Selection)){
                                                       $data = array(  
                                                        ''=> 'Select as appropriate',
                                                        'buy' => 'Buy agricultural products', 
                                                        'sell' => 'Sell agricultural products',
                                                        );
                                                        echo form_dropdown('selection',$data, set_value('selection'),array('class'=> 'form-control','name' => 'selection'));
                                                    }else{
                                                        $data = array(  
                                                        'buy' => ucfirst($profile->Selection).' agricultural products', 
                                                        );
                                                            echo form_dropdown('selection',$data, set_value('selection'),array('class'=> 'form-control','name' => 'selection'));
                                                    }
                                                    
                                                ?>
                                            </div>
                                            
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">group</i>
										      </span>
										          <input type="text" class="form-control" placeholder="<?php if(empty($profile->NOC)){echo 'Name of company';}else{ echo  $profile->NOC;} ?>" name = "noc" required>
									       </div>
                                        </div>
                                        <div class = "col-lg-6">
                                            <div class="form-group">
                                                <?php 
                                                    if(empty($profile->Location)){
                                                       $data = array(  
                                                        ""=> "Select the location of your company",
                                                        'lagos' => 'Lagos', 
                                                        'enugu' => 'Enugu',
                                                    );
                                                    echo form_dropdown('location',$data,set_value('location'),array('class'=> 'form-control','name' => 'location'));
                                                    }else{
                                                        $data = array(  
                                                        'buy' => ucfirst($profile->Location), 
                                                        );
                                                            echo form_dropdown('location',$data, set_value('location'),array('class'=> 'form-control','name' => 'location'));
                                                    }
                                                    
                                                ?>
                                            </div>
                                            
                                        </div>
                                        <div class = "col-lg-12">
                                            <textarea class="form-control" rows="4" required placeholder="<?php if(empty($profile->Description)){echo 'What would you like to achieve on this platform...max of 1000 characters';}else{ echo  $profile->Description;} ?>" name = "description"></textarea>
                                        </div>
                                        
                                        
                                        <?php 
                                            if($_SESSION['link'] == 'valid'){
                                                    echo '<button type = "button" class = "btn btn-success" disabled><i class = "material-icons">done_all</i> Already Done</button>';
                                                }else{
                                                    echo '<button type = "submit" name = "submit" class = "btn btn-success"><i class = "material-icons">done</i> Finish up</button>';
                                                }
                                        ?>
                                    </div>
                                <?php echo form_close(); ?>
                                    
                                    
									<div class="tab-pane" id="edit">
										<h4>EDIT YOUR DATA</h4>
                                        
                    <?php echo $this->session->flashdata('not_changed'); ?>
                        <?php echo $this->session->flashdata('correct'); ?>
                            <?php echo $this->session->flashdata('incorrect'); ?>
                                <?php echo $this->session->flashdata('email_changed'); ?>
                                    <?php echo $this->session->flashdata('email_errror'); ?>
                                        <?php echo $this->session->flashdata('null'); ?>
                                            <?php echo $this->session->flashdata('data_updated'); ?>
                                            <?php echo $this->session->flashdata('not_deleted'); ?>
    
                                        
                                <?php echo form_open('Main/update_data'); ?>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">face</i>
										      </span>
										          <input type="text" class="form-control" placeholder="Change First Name" name = "fname" required>
									       </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">face</i>
										      </span>
										          <input type="text" class="form-control" placeholder="Change Last Name" name = "lname" required>
									       </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">phone</i>
										      </span>
										          <input type="text" class="form-control" placeholder="Change Phone Number" name = "phone" required>
									       </div>
                                        </div>
                                        
                                        <?php 
                                            if($_SESSION['link'] == 'valid'){
                                                 echo '<button type = "submit" name= "change" class = "btn btn-success">Update Details</button> ';
                                                }else{
                                                   echo '<button type = "button" class = "btn btn-success" disabled><i class = "material-icons">info</i> Profile Not Updated</button>';
                                                }
                                        ?>
                                            
                                <?php echo form_close(); ?>
                                               
                                        <!--EMAIL ADDRESS-->
                                            <h4>CHANGE EMAIL ADDRESS</h4>
                                <?php echo form_open('Main/change_email'); ?>
                                        <div class="col-lg-12">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">mail_outline</i>
										      </span>
										          <input type="email" class="form-control" placeholder="Change Email Address" name = "email" required>
									       </div>
                                        </div>
                                            <button type = "submit" name = "change" class = "btn btn-info">Change Email</button>   
                                <?php echo form_close(); ?>
                                                
                                        <!--PASSWORD CHANGE-->
                                            <h4>CHANGE PASSWORD</h4>
                                    <?php echo form_open('Main/change_password'); ?>
                                        <div class="col-lg-12">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">lock_open</i>
										      </span>
										          <input type="password" class="form-control" placeholder="Old password" name = "old_pword" required>
									       </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">lock_outline</i>
										      </span>
										          <input type="password" class="form-control" placeholder="New password" name = "new_pword" required>
									       </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="input-group">
										      <span class="input-group-addon">
											     <i class="material-icons">lock_outline</i>
										      </span>
										          <input type="password" class="form-control" placeholder="Confirm password" name = "c_pword" required>
									       </div>
                                        </div>
                                        
                                        <button type = "submit" class = "btn btn-danger" name = "reset">Change Password</button>
									</div>
                                <?php echo form_close(); ?>
                                    
                                    
									<div class="tab-pane" id="orders">
                                        <?php
                                            if($_SESSION['link'] == 'valid'){
                                                echo '
                                                        <table class="table table-hover"> <caption>Transactions Table</caption>
                                                        <thead>
                                                            <tr>
                                                                <th class = "text-center">Date</th>
                                                                <th class = "text-center">Order</th>
                                                                <th class = "text-center">Description</th>
                                                                <th class = "text-center">Duration given</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>NO ORDERS</td>
                                                                <td>NO ORDERS</td>
                                                                <td>NO ORDERS</td>
                                                                <td>NO ORDERS</td>
                                                            </tr>
                                                        </tbody>
                                                       </table>
                                                <a href = "#orderModal" data-toggle = "modal" class = "btn btn-info">Make an order</a>';
                                            }else{
                                                    echo '<p>Notice: You have to update your profile before you can perform any transaction';
                                                    echo '
                                                    
                                                       <table class="table table-hover"> <caption>Transactions Table</caption>
                                                        <thead>
                                                            <tr>
                                                                <th class = "text-center">Date</th>
                                                                <th class = "text-center">Order</th>
                                                                <th class = "text-center">Description</th>
                                                                <th class = "text-center">Duration given</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>NULL</td>
                                                                <td>NULL</td>
                                                                <td>NULL</td>
                                                                <td>NULL</td>
                                                            </tr>
                                                        </tbody>
                                                       </table>
                                                   
                                                    
                                                    <button type = "button" class = "btn btn-info" disabled>Make an order</button>
                                                    ';
                                                }             
                                        ?>
                                        <!-- -->
									</div>
								</div>
							</div>
						</div>
						<!-- End Tabs with icons on Card -->

                    </div>
				</div> 
                    
	                <div class="description text-center">
                        <p> </p>
	                </div>
                    	
			
		
		

					
	            </div>
	        </div>
		</div>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	           <div class="modal-dialog">
		          <div class="modal-content">
			         <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					       <i class="material-icons">clear</i>
				        </button>
				            <h4 class="modal-title">Delete Account</h4>
			         </div>
			         <div class="modal-body">
                        <?php echo form_open('Main/delete_user'); ?>
				            <div class="col-lg-12">
		                	     <div class="form-group">
		        	        	    <textarea name = "lstMsg" placeholder = "Before you go leave us with a message..." rows = "4" required class = "form-control"></textarea>
                                     <input type = "hidden" name = "userName" value = "<?= $profile->fName.' '.$profile->lName;?>"/> 
                                     <input type = "hidden" name = "userPhone" value = "<?= $profile->Phone; ?>"/> 
		                	     </div>
		                  </div>
			         </div>
			         <div class="modal-footer">
				            <button type="button" class="btn btn-simple " data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger ">Delete account</button>
			         </div>
                    <?php echo form_close(); ?>
		      </div>
	</div>
</div>
        <div class="modal fade" id="orderModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	           <div class="modal-dialog">
		          <div class="modal-content">
			         <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					       <i class="material-icons">clear</i>
				        </button>
				            <h4 class="modal-title">Make an order</h4>
                            <button type="button" class="btn btn-default btn-round btn-xs" data-toggle="popover" data-placement="top" title="" data-content="You opted in to <?= $profile->Selection; ?> agricultural items, please fill in orders with relation to that. Click this button to close this content" data-container="body" data-original-title="Help"><i class = "material-icons">help</i><div class="ripple-container"></div></button>
			         </div>
			         <div class="modal-body">
                        <?php echo form_open('Main/create_order'); ?>
                         <div class="col-lg-6">
		                	     <div class="form-group">
                                     <?php 
                                        if($profile->Selection == "sell"){
                                            echo '<input type = "text" class = "form-control" name = "itemName" placeholder="Name of the product[s] you wish to sell" required/>';
                                        }else{
                                            echo '<input type = "text" class = "form-control" name = "itemName" placeholder="Name of the product[s] you require" required/>';
                                        }                    
                                    ?>
		                	     </div>
		                  </div>
                         <div class="col-lg-6">
		                	     <div class="form-group">
                                     <?php 
                                        if($profile->Selection == "sell"){
                                            echo '<input type = "numbers" class = "form-control" name = "price" placeholder="Price range to sell the product[s]" required/>';
                                        }else{
                                            echo '<input type = "numbers" class = "form-control" name = "price" placeholder="Price range you can afford" required/>';
                                        }                    
                                    ?>
		                	     </div>
		                  </div>
                        <div class = "col-lg-12">
                            <div class="form-group">
                                <?php 
                                    $data = array(
                                    '' => 'Product Size',
                                    'Small' => 'Small', 
                                    'Medium' => 'Medium', 
                                    'Large' => 'Large', 
                                    );
                                    echo form_dropdown('location',$data, set_value('location'),array('class'=> 'form-control','name' => 'location'));
                                                 
                                ?>
                            </div>                                            
                        </div>
                          <div class = "col-lg-12">
                                    <div class="form-group">
                         <?php 
                            if($profile->Selection == 'buy'){    
                                 $data = array(
                                    '' => 'How fast do you require this item',
                                    '3' => 'Within 3 Days', 
                                    '7' => 'Within 7 Days', 
                                    '2weeks' => 'Within 2 weeks', 
                                    );
                                    echo form_dropdown('duration',$data, set_value('duration'),array('class'=> 'form-control','name' => 'duration'));
                            } else{
                                
                                        $data = array(
                                            '' => 'How long will this offer be available',
                                            '3' => 'Within 3 Days', 
                                            '7' => 'Before 7 Days', 
                                            '2weeks' => 'Within 2 weeks', 
                                        );
                                        echo form_dropdown('duration',$data, set_value('duration'),array('class'=> 'form-control','name' => 'duration'));
                            }                                 
                        ?>
                              </div>                                            
                        </div>
                         
                         <div class="col-lg-12">
		                	     <div class="form-group">
		        	        	    <textarea name = "description" placeholder = "Add a note to this order..." rows = "4"   required class = "form-control"></textarea>
		                	     </div>
		                  </div>
			         </div>
			         <div class="modal-footer">
				            <button type="button" class="btn btn-simple " data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success ">Order</button>
			         </div>
                    <?php echo form_close(); ?>
		      </div>
	</div>
</div>


			

        

<?php
        }else{
            redirect('login');
        }
?>