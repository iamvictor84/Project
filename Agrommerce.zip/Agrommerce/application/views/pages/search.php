<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
        if(empty($this->input->post('search'))){
            redirect('home');
        }
?>
<div class="main_bg">
	<div class="main">	   		           	         
		<div class="latest-products">
		<h2 class="style top">
            <?php
                if(empty($results)){
                    echo 'Sorry, we could not find any item with such keyword.';
                }else{
                    echo "Showing items with the keyword '".ucfirst($this->input->post('search'))."'.";
                }
            ?>
        </h2>
		<!-- start grids_of_3 -->
		<div class="grids_of_3">
            <?php 
                foreach($results as $value){
                    ?>
                        <div class="grid1_of_3">
				            <a href="<?php echo base_url(); ?>item">
                                <?php
                                    if(empty($value->imageName)){
                                         ?>
                                            <img src="<?php echo base_url(); ?>images/logo.jpg" alt="" style = "height:178px;"/> 
                                        <?php
                                    }else{
                                        ?>
                                            <img src="<?php echo base_url(); ?>images/<?= $value->imageName; ?>" alt=""/>      
                                        <?php
                                    }
                                ?>
					           <h3><?=$value->itemName; ?></h3>
					               <div class="price1">
						              <h4> <b>&#8358; <?= $value->itemPrice; ?> </b> Per <?= $value->itemMeasurement; ?>
                                          
                                          <br/><br/>
                                          <span>Add To Order</span></h4>
					               </div>
					           <span class="b_btm"></span>
				        </a>
			         </div>
                    <?php
                }
            ?>
			
            <div class="clearfix"></div>
		</div>
		<!-- end grids_of_3 -->
	</div>
	<div class="sub-cate">
				<div class=" top-nav rsidebar span_1_of_left">
					<h3 class="cate">CATEGORIES</h3>
		 <ul class="menu">
		<li class="item1"><a href="#">Curabitur sapien<img class="arrow-img" src="<?php echo base_url(); ?>images/arrow1.png" alt=""/> </a>
			<ul class="cute">
				<li class="subitem1"><a href="products.html">Cute Kittens </a></li>
				<li class="subitem2"><a href="products.html">Strange Stuff </a></li>
				<li class="subitem3"><a href="products.html">Automatic Fails </a></li>
			</ul>
		</li>
		<li class="item2"><a href="#">Dignissim purus <img class="arrow-img " src="images/arrow1.png" alt=""/></a>
			<ul class="cute">
				<li class="subitem1"><a href="products.html">Cute Kittens </a></li>
				<li class="subitem2"><a href="products.html">Strange Stuff </a></li>
				<li class="subitem3"><a href="products.html">Automatic Fails </a></li>
			</ul>
		</li>
		<li class="item3"><a href="#">Ultrices id du<img class="arrow-img img-arrow" src="images/arrow1.png" alt=""/> </a>
			<ul class="cute">
				<li class="subitem1"><a href="products.html">Cute Kittens </a></li>
				<li class="subitem2"><a href="products.html">Strange Stuff </a></li>
				<li class="subitem3"><a href="products.html">Automatic Fails</a></li>
			</ul>
		</li>
		<li class="item4"><a href="#">Cras iacaus rhone <img class="arrow-img img-left-arrow" src="images/arrow1.png" alt=""/></a>
			<ul class="cute">
				<li class="subitem1"><a href="products.html">Cute Kittens </a></li>
				<li class="subitem2"><a href="products.html">Strange Stuff </a></li>
				<li class="subitem3"><a href="products.html">Automatic Fails </a></li>
			</ul>
		</li>
				<li>
			<ul class="kid-menu">
				<li><a href="products.html">Tempus pretium</a></li>
				<li ><a href="products.html">Dignissim neque</a></li>
				<li ><a href="products.html">Ornared id aliquet</a></li>
			</ul>
		</li>
		<ul class="kid-menu ">
				<li><a href="products.html">Commodo sit</a></li>
				<li ><a href="products.html">Urna ac tortor sc</a></li>
				<li><a href="products.html">Ornared id aliquet</a></li>
				<li><a href="products.html">Urna ac tortor sc</a></li>
				<li ><a href="products.html">Eget nisi laoreet</a></li>
				<li><a href="products.html">Faciisis ornare</a></li>
				<li class="menu-kid-left"><a href="contact.html">Contact us</a></li>
			</ul>
	</ul>
					</div>
				<!--initiate accordion-->
		<script type="text/javascript">
			$(function() {
			    var menu_ul = $('.menu > li > ul'),
			           menu_a  = $('.menu > li > a');
			    menu_ul.hide();
			    menu_a.click(function(e) {
			        e.preventDefault();
			        if(!$(this).hasClass('active')) {
			            menu_a.removeClass('active');
			            menu_ul.filter(':visible').slideUp('normal');
			            $(this).addClass('active').next().stop(true,true).slideDown('normal');
			        } else {
			            $(this).removeClass('active');
			            $(this).next().stop(true,true).slideUp('normal');
			        }
			    });
			
			});
		</script>
					<div class=" chain-grid menu-chain text-center">
	   		     		<a href="products.html"><img class="img-responsive chain" src="images/phone.jpg" alt=" " /></a>	   		     		
	   		     		<div class="grid-chain-bottom chain-watch">
		   		     		<span class="actual dolor-left-grid">300$</span>
		   		     		<span class="reducedfrom">500$</span>  
		   		     		<h6>Lorem ipsum dolor</h6>  		     			   		     										
	   		     		</div>
	   		     	</div>
	   		     	 <a class="view-all all-product" href="products.html">VIEW ALL PRODUCTS<span> </span></a> 	
					  <div class="clearfix"> </div>
			</div>
	 <div class="clearfix"> </div>
</div>
</div>
</div>	
