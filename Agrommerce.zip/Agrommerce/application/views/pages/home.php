<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<div class="main-top">
			<div class="col-md-8 banner">
				<div class="slider">	  
					  <div class="callbacks_container">
						  <ul class="rslides" id="slider">
							 <li>
								 <img src="<?php echo base_url(); ?>images/cabbages.jpg" alt="" style = "height:387px;" />
							 </li>
							 <li>
								 <img src="<?php echo base_url(); ?>images/potato.jpg" alt="" style = "height:387px;"/>
							 </li>
							 <li>
								 <img src="<?php echo base_url(); ?>images/pepper.jpg" alt="" style = "height:387px;"/>
							 </li>
						  </ul>	      
					  </div>
				</div>
				
				<!-- end  slider -->
		   </div>
		   <div class="col-md-4 right-grid">
				<div class="right-grid-top">
					<div class="r-sale text-center">
						<h6>DISCOUNT &</h6>
						<h2>DEAL</h2>
					</div>
					<div class="r-discount">
						<span>UPTO</span>
						<h2>5%</h2>
						<p>OFF</p>
						<a href="#">ORDER NOW<i class="go"></i></a>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="right-grid-bottom">
					<div class="right-grid-bottom-left">
						<h3>Weekly Deals</h3>
						<p>Expires in 3:42:56</p>
						<h5>First Time Buyers</h5>
						<h2> 10% OFF</h2>
							<a href="<?php echo base_url(); ?>roots-tubers">ORDER NOW<i class="go"></i></a>
					</div>
					<div class="right-grid-bottom-right">
						<img src="<?php echo base_url(); ?>images/spring.png" alt="Logo" />
					</div>
					<div class="clearfix"></div>
				</div>
		   </div>
		   <div class="clearfix"></div>
		</div>
		<div class="new-arrivals text-center">
			<div class="col-md-3 new-arrival-head">
				<h3>TOP REQUESTED</h3>
				<a class="btn btn-1 btn-1d" href="products.html">CREATE ORDER</a>
			</div>
			<div class="col-md-3 product-item">
				<a href="<?php echo base_url(); ?>fruits"><img src="<?php echo base_url(); ?>images/oranges.jpeg" class="img-responsive" alt="" style = "height:184px" /></a>
				<h3>ORANGES</h3>
				<a href="<?php echo base_url(); ?>fruits">VIEW ITEM<i class="go"></i></a>
			</div>
			<div class="col-md-3 product-item">
				<a href="<?php echo base_url(); ?>spices"><img src="<?php echo base_url(); ?>images/spices.jpeg" class="img-responsive zoom-img" alt="" style = "height:184px"/></a>
				<h3>SPICES</h3>
				<a href="<?php echo base_url(); ?>spices">VIEW ITEM<i class="go"></i></a>
			</div>
			<div class="col-md-3 product-item">
				<a href="<?php echo base_url(); ?>livestock"><img src="<?php echo base_url(); ?>images/fowl.jpeg" class="img-responsive zoom-img" alt="" style = "height:184px"/></a>
				<h3>LIVE CHICKENS</h3>
				<a href="<?php echo base_url(); ?>livestock">VIEW ITEM<i class="go"></i></a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="best-sellers">
			<div class="best-sellers-head">
				<h3>Freshly Available</h3>
			</div>
			
			<div class="clearfix"></div>
		</div>
		<div class="device">
			<div class="course_demo">
		          <ul id="flexiselDemo">	
					<li>
						<div class="ipad text-center">
							<img src="images/fresh-carrots.jpeg" alt="" style = "height:115px;width:100px;" />
							<h4>Carrots</h4>
								<h3>&#8358; 7000 Per Basket</h3>
							<ul>
								<li><i class="cart-1"></i></li>
								<li><a class="cart" href="#">Add To Cart</a></li>
							</ul>
							<div class="clearfix"></div>
							
						</div>
					</li>
					<li>
						<div class="ipad text-center">
							<img src="<?php echo base_url(); ?>images/unriped.jpeg" alt="" style = "height:115px;width:100px;" />
							<h4>Unriped Banana</h4>
								<h3>&#8358; 9000 Per Basket</h3>
							<ul>
								<li><i class="cart-1"></i></li>
								<li><a class="cart" href="#">Add To Cart</a></li>
							</ul>
							<div class="clearfix"></div>
							
						</div>
					</li>
					<li>
						<div class="ipad text-center">
							<img src="images/red-apples.jpeg" alt="" style = "height:115px;width:100px;" />
							<h4>Red-Apples</h4>
								<h3>&#8358; 5000 Per Crates</h3>
							<ul>
								<li><i class="cart-1"></i></li>
								<li><a class="cart" href="#">Add To Cart</a></li>
							</ul>
							<div class="clearfix"></div>
							
						</div>
					</li>
					<li>
						<div class="ipad text-center">
							<img src="<?php echo base_url(); ?>images/tomatoes.jpeg" alt="" style = "height:115px;width:100px;" />
							<h4>Tomatoes</h4>
								<h3>&#8358; 4000 Per Basket</h3>
							<ul>
								<li><i class="cart-1"></i></li>
								<li><a class="cart" href="#">Add To Cart</a></li>
							</ul>
							<div class="clearfix"></div>
							
						</div>
					</li>
					<li>
						<div class="ipad text-center">
							<img src="<?php echo base_url(); ?>images/eggs.jpeg" alt="" style = "height:115px;width:100px;" />
							<h4>Layers-Egg</h4>
								<h3>&#8358; 1000 Per Crate</h3>
							<ul>
								<li><i class="cart-1"></i></li>
								<li><a class="cart" href="#">Add To Cart</a></li>
							</ul>
							<div class="clearfix"></div>
							
						</div>
					</li>						    	  	       	   	  									    	  	       	   	    	
				</ul>
	  </div>
	  </div>
	  <div class="clients">
		<div class="course_demo1">
		          <ul id="flexiselDemo1">
					<li>
						<div class="client">
							<img src="<?php echo base_url(); ?>images/chitis.png" alt="" />
						</div>
					</li>
					<li>
					    <div class="client">
							<img src="<?php echo base_url(); ?>images/dangote.png" alt="" />
						</div>
					</li>	
				</ul>
			</div>
			<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/flexslider.css" type="text/css" media="screen" />
				<script type="text/javascript">
			$(window).load(function() {
				$("#flexiselDemo1").flexisel({
					visibleItems: 7,
					animationSpeed: 1000,
					autoPlay: false,
					autoPlaySpeed: 3000,    		
					pauseOnHover: true,
					enableResponsiveBreakpoints: true,
			    	responsiveBreakpoints: { 
			    		portrait: { 
			    			changePoint:480,
			    			visibleItems: 1
			    		}, 
			    		landscape: { 
			    			changePoint:640,
			    			visibleItems: 2
			    		},
			    		tablet: { 
			    			changePoint:768,
			    			visibleItems: 3
			    		}
			    	}
			    });
			    
			});
		</script>
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.flexisel.js"></script>
		</div>
		<div class="transport-grid">
			<div class="col-md-4 shipping">
				<h3><i class="shipping-icon"></i>Delivery Service</h3>
				<p>We deliver the items requested for to your destination.</p>
			</div>
			<div class="col-md-4 shipping">
				<h3><i class="correct-icon"></i>100 % Guarantee</h3>
				<p>We provide services all round the country and buy directly from the farmers making it easily accessed by all.</p>
			</div>
			<div class="col-md-4 return">
				<h3><i class="return-icon"></i>Price Rates</h3>
				<p>We charge based on the total expense of the items requested for and also at negiotable price rates.</p>
			</div>
			<div class="clearfix"></div>
		</div>
	  </div>
	 