<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<div class="sub-banner">
	<div class = "layer">
		<p>
			<img src = "<?php echo base_url(); ?>images/icon.png" style="width:300px;height: 100px;" />
		</p>
			<h2 >Putting the commerce in agriculture.</h2>
	</div>
</div>
<div class="contact">
	<div class="container">
		<h3>Contact Us</h3>
		<div class="col-md-3 col-sm-3 contact-left">
			<div class="address">
				<h4>ADDRESS</h4>
				<h5>Roar Hub Nigeria</h5>
				<h5>University Of Nigeria.</h5>
				<h5>Nsukka, Enugu state.</h5>
			</div>
			<div class="phone">
				<h4>PHONE</h4>
				<h5> +234-81-6333-2025</h5>
			</div>
			<div class="email">
				<h4>EMAIL</h4>
				<h5><a href="http://info@agrommerce.com.ng">info@agrommerce.com.ng</a></h5>
			</div>
		</div>
		<div class="col-md-9 col-sm-9 contact-right">
			<form action="#" method="post">
				<input type="text" name="your name" placeholder="Your name" required="true">
				<input type="text" name="your email" placeholder="Your email" required="true">
				<input type="text" name="your subject" placeholder="Your subject" required="true">
				<input type="text" name="your phone number" placeholder="Phone number" required="true">
				<textarea  name="your message" placeholder="Your message" required=" "></textarea>
				<input type="submit" value="Send message">
			</form>
		</div>
	</div>
</div>