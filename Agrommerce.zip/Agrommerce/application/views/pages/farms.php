<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
    <div class="wrapper">
		<div class="header header-filter" style="background-image: url('<?php echo base_url(); ?>images/banner.jpg');"></div>

		<div class="main main-raised">
			<div class="profile-content">
	            <div class="container">
	                <div class="description text-center">
                        <p>The items on this website are supplied by large scale farmers based on the item/product been requested for. You can place a customized order by viewing the farm with the item you require. </p>
	                </div>
                    
                    
                <div id="images">
	                 <div class="title">
	                    <h2>Our Farms</h2>
	                </div>
	                
                    <div class="row">
						<div class="col-sm-4">
	                        <img src="<?php echo base_url(); ?>images/farm1.jpeg" alt=" " class="img-responsive img-raised" style = "height: 250px;width:300px;">
                             <h4>
                                UNN Farms
                            </h4>
                                <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "Yam" name = "itemName"/>
                                    <input type = "hidden" value = "500" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                     <button class="btn btn-primary btn-sm" type = "submit" >
                                        <i class = "material-icons">arrow_forward</i> View</button>
                                </form>
	                    </div>
                        <div class="col-sm-4">
	                        <img src="<?php echo base_url(); ?>images/farm6.jpeg" alt=" " class="img-responsive img-raised" style = "height: 250px;width:300px;">
                             <h4>
                                Obidieze Livestock and Poultry
                            </h4>
                                <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "Yam" name = "itemName"/>
                                    <input type = "hidden" value = "500" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                     <button class="btn btn-primary btn-sm" type = "submit" >
                                        <i class = "material-icons">arrow_forward</i> View</button>
                                </form>
	                    </div>
                        <div class="col-sm-4">
	                        <img src="<?php echo base_url(); ?>images/farm2.jpeg" alt=" " class="img-responsive img-raised" style = "height: 250px;width:300px;">
                             <h4>
                                Mohammed's Farm
                            </h4>
                                <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "Yam" name = "itemName"/>
                                    <input type = "hidden" value = "500" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                     <button class="btn btn-primary btn-sm" type = "submit" >
                                        <i class = "material-icons">arrow_forward</i> View</button>
                                </form>
	                    </div>
                        <div class="col-sm-4">
	                        <img src="<?php echo base_url(); ?>images/farm3.jpeg" alt=" " class="img-responsive img-raised" style = "height: 250px;width:300px;">
                             <h4>
                                Kate's Poultry
                            </h4>
                                <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "Yam" name = "itemName"/>
                                    <input type = "hidden" value = "500" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                     <button class="btn btn-primary btn-sm" type = "submit" >
                                        <i class = "material-icons">arrow_forward</i>View</button>
                                </form>
	                    </div>
                        <div class="col-sm-4">
	                        <img src="<?php echo base_url(); ?>images/farm4.jpeg" alt=" " class="img-responsive img-raised" style = "height: 250px;width:300px;">
                             <h4>
                                Ogige Poultry
                            </h4>
                                <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "Yam" name = "itemName"/>
                                    <input type = "hidden" value = "500" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                     <button class="btn btn-primary btn-sm" type = "submit" >
                                        <i class = "material-icons">arrow_forward</i> View</button>
                                </form>
	                    </div>
                        <div class="col-sm-4">
	                        <img src="<?php echo base_url(); ?>images/farmer.jpg" alt=" " class="img-responsive img-raised" style = "height: 250px;width:300px;">
                             <h4>
                                Ejike Chris Plantations
                            </h4>
                                <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "Yam" name = "itemName"/>
                                    <input type = "hidden" value = "500" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                     <button class="btn btn-primary btn-sm" type = "submit" >
                                        <i class = "material-icons">arrow_forward</i> View</button>
                                </form>
                        </div>
	               </div>	
	            </div>
                    <br/><br/>
                    <div class="col-xs-8 col-xs-offset-2 col-sm-4 col-sm-offset-4">
						<a href="#addFarm" class="btn btn-success btn-block" data-toggle = "modal">
							<i class="material-icons">unarchive</i> Add your farm
						</a>
					</div>
	           </div>  
		</div>  
    </div>
        <div class="modal fade" id="addFarm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	               <div class="modal-dialog">
		              <div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					<i class="material-icons">clear</i>
				</button>
				    <h4 class="modal-title">Add Farm</h4>
                        <h6>Notice: Your farm will not be valid until a successful transaction has been performed with this platform.</h6>
                    <hr/>
			</div>
			<div class="modal-body">
				<div class="col-lg-12">
		                	<div class="form-group">
		        	        	<input type="email" placeholder="Type your email address..." class="form-control" name = "email" required/>
		                	</div>
		                </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success btn-simple">Reset</button>
			</div>
		</div>
	</div>
</div>
        
        

    