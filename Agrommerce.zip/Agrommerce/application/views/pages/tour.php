<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<div class="wrapper">
        <div class="header header-filter" style="background-image: url('<?php echo base_url(); ?>images/banner.jpg');">
            <div class="container">
                <div class="row">
					<div class="col-md-6">
						<h1 class="title" style = "color:#4caf50;">Agrommerce</h1>
							<h4>Complimenting and fastracking the agricultural supply chain with technology, we are poised to bolster agricultural commerce in Africa and beyond.</h4>
	                    	
	                    <br />
	                    <a href="https://agrommerce.blogspot.com" class="btn btn-success btn-raised btn-lg">
							<i class="material-icons">lightbulb_outline</i> Learn More
						</a>
					</div>
					</div>
                </div>
            </div>
        </div>
        
        <div class="main main-raised">
			<div class="container">
		    	<div class="section text-center section-landing">
	                    <div class="col-md-8 col-md-offset-2">
	                        <h2 class="title">Let's show you around</h2>
	                        <h5 class="description">Take a quick look at how things are done, sneak peek at our items in store and even check out how to order our items.</h5>
	                    </div>
	                
                    
                        <div class="features">
						      <div class="row">
		                          <div class="col-md-4">
								        <div class="info">
									       <div class="icon icon-primary">
										          <i class = "material-icons">shopping_basket</i>
									       </div>
									           <p>Sneak peek into our stores and see the produce we gather from different farms around the country.</p>
                                                    <a href = "#demoModal" data-toggle = "modal" class = "btn btn-success btn-block">Show me</a>
								        </div>
		                          </div>
		                          <div class="col-md-4">
								    <div class="info">
									       <div class="icon icon-warning">
										          <i class = "material-icons">shopping_cart</i>
									       </div>
									           <p>Take the easy way to order for items, The Agrommerce way. </p>
                                                    <a href = "#" class = "btn btn-warning btn-block">Request Item</a>
								        </div>
		                          </div>
		                    <div class="col-md-4">
								<div class="info">
									       <div class="icon icon-info">
										          <i class = "material-icons">touch_app</i>
									       </div>
									           <p>Join Agrommerce today and together we can feed the nation.</p>
                                                    <a href = "<?php echo base_url(); ?>register" class = "btn btn-info btn-block">Join us</a>
								        </div>
		                    </div>
		                
                    
                        <div class="col-md-8 col-md-offset-2">
	                        <h2 class="title">Top Requested</h2>
	                           <h5 class="description">Some of the top requested items we have been able to deliver through our platform</h5>
                            	<div class="card card-raised card-carousel">
							<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
								<div class="carousel slide" data-ride="carousel">

									<!-- Indicators -->
									<ol class="carousel-indicators">
										<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
										<li data-target="#carousel-example-generic" data-slide-to="1"></li>
										<li data-target="#carousel-example-generic" data-slide-to="2"></li>
									</ol>

									<!-- Wrapper for slides -->
									<div class="carousel-inner">
										<div class="item active">
											<img src="<?php echo base_url(); ?>images/potato.jpg" alt="Awesome Image" style = "width:800px;height:400px;" class = "img-responsive">
											<div class="carousel-caption">
												<h4><i class="material-icons">store</i> Kilograms of potatoes</h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo base_url(); ?>images/cabbages.jpg" alt="Awesome Image" style = "width:800px;height:400px;" class = "img-responsive">
											<div class="carousel-caption">
												<h4><i class="material-icons">store</i> Well preserved vegetables</h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo base_url(); ?>images/pepper.jpg" alt="Awesome Image"style = "width:800px;height:400px;" class = "img-responsive" >
											<div class="carousel-caption">
												<h4><i class="material-icons">store</i>Quality food spices</h4>
											</div>
										</div>
									</div>

									<!-- Controls -->
									<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
										<i class="material-icons">keyboard_arrow_left</i>
									</a>
									<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
										<i class="material-icons">keyboard_arrow_right</i>
									</a>
								</div>
							</div>
						</div>
                    </div>       
                </div>
                </div>                    
                </div>
            </div>
        </div>
                
	               
                <div class="modal fade" id="demoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	               <div class="modal-dialog">
		              <div class="modal-content">
			             <div class="modal-header">
				            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					           <i class="material-icons">clear</i>
				            </button>
				                <h4 class="modal-title">Take a Tour</h4>
                                    <h6>Notice: These items are subject to change in price and any item price can be altered when seen fit.</h6>
                            <hr/>
			             </div>
			             <div class="modal-body">
                            <div class = "row">
                                <div class="col-sm-4">
	                               <img src="<?php echo base_url(); ?>images/cocoyam.jpg" alt=" " class="img-responsive img-raised" style = "height: 165px;width:250px;">
                                        <h4>Cocoyam
                                            <br> &#8358; 55 Per Item
                                        </h4>
                                        <form action = "<?php echo base_url(); ?>item" method = "POST">
                                            <input type = "hidden" value = "cococyam" name = "itemName"/>
                                            <input type = "hidden" value = "55" name = "itemPrice"/>
                                            <input type = "hidden" value = "small" name = "itemSize"/>
                                            <input type = "hidden" value = "7" name = "itemDelivery"/>
                                     <button class="btn btn-primary btn-sm btn-round" type = "submit" >Order Item</button>
                                </form>
                                
	                            </div>
                                <div class="col-sm-4">
	                               <img src="<?php echo base_url(); ?>images/carrot.jpg" alt=" " class="img-responsive img-raised" style = "height: 165px;width:250px;">
                                        <h4>Carrots
                                            <br> &#8358; 35 Per Item
                                        </h4>
                                              <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "carrot" name = "itemName"/>
                                    <input type = "hidden" value = "35" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                    <input type = "hidden" value = "3" name = "itemDelivery"/>
                                     <button class="btn btn-primary btn-sm btn-round" type = "submit" >Order Item</button>
                                </form>
                                
	                            </div>
                                <div class="col-sm-4">
	                               <img src="<?php echo base_url(); ?>images/apple.jpg" alt=" " class="img-responsive img-raised" style = "height: 165px;width:250px;">
                                        <h4>Apples
                                            <br> &#8358; 80 Per Item
                                        </h4>
                                              <form action = "<?php echo base_url(); ?>item" method = "POST">
                                    <input type = "hidden" value = "apple" name = "itemName"/>
                                    <input type = "hidden" value = "80" name = "itemPrice"/>
                                    <input type = "hidden" value = "Medium" name = "itemSize"/>
                                    <input type = "hidden" value = "3" name = "itemDelivery"/>
                                     <button class="btn btn-primary btn-sm btn-round" type = "submit" >Order Item</button>
                                </form>
                                
	                            </div>
                                    
                            </div>
			         </div>
			         <div class="modal-footer">
                         
				        <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
			         </div>
		          </div>
	           </div>
        </div>
           