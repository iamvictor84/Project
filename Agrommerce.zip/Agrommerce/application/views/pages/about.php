<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<div class="wrapper">
		<div class="header header-filter" style="background-image: url('<?php echo base_url(); ?>images/banner.jpg');"></div>

		<div class="main main-raised">
			<div class="profile-content">
	            <div class="container">
                    <div class="section" id="carousel">
			             <div class="container">
				            <div class="row">
					           <div class="col-md-8 col-md-offset-2">

						<!-- Carousel Card -->
						<div class="card card-raised card-carousel">
							<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
								<div class="carousel slide" data-ride="carousel">

									<!-- Indicators -->
									<ol class="carousel-indicators">
										<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
										<li data-target="#carousel-example-generic" data-slide-to="1"></li>
										<li data-target="#carousel-example-generic" data-slide-to="2"></li>
									</ol>

									<!-- Wrapper for slides -->
									<div class="carousel-inner">
										<div class="item active">
											<img src="<?php echo base_url(); ?>images/logo.jpg" alt="Awesome Image" style = "width:800px;height:400px;" class = "img-responsive">
											<div class="carousel-caption">
												<h4><i class="material-icons">location_on</i> Agrommerce is the next big thing.</h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo base_url(); ?>images/apples.jpg" alt="Awesome Image" style = "width:800px;height:400px;" class = "img-responsive">
											<div class="carousel-caption">
												<h4><i class="material-icons">location_on</i> We assure only of the best.</h4>
											</div>
										</div>
										<div class="item">
											<img src="<?php echo base_url(); ?>images/onions.jpg" alt="Awesome Image"style = "width:800px;height:400px;" class = "img-responsive" >
											<div class="carousel-caption">
												<h4><i class="material-icons">location_on</i>Only the right and riped items are chosen for sale</h4>
											</div>
										</div>
									</div>

									<!-- Controls -->
									<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
										<i class="material-icons">keyboard_arrow_left</i>
									</a>
									<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
										<i class="material-icons">keyboard_arrow_right</i>
									</a>
								</div>
							</div>
						</div>
						<!-- End Carousel Card -->

					</div>
				</div>
			</div>
		</div>