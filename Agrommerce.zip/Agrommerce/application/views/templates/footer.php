<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
    <script>
			     jQuery(document).ready(function($){
				    $('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 800,
					source_image_height: 1000,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>
</div>
</div>
 <div class="footer">
		<div class="wrap">
			<div class="contact-section">
				<div class="col-md-4 follow text-left">
					<h3>Follow Us</h3>
					<p>Share the word and get free coupons</p>
					<div class="social-icons">
						<i class="twitter"></i>
						<i class="facebook"></i>
						<i class="googlepluse"></i>
						<i class="linkedin"></i>
					</div>
				</div>
				<div class="col-md-4 subscribe text-left">
					<h3>Newsletter</h3>
					<p>Be the first to get fresh updates</p>
                    <?php echo form_open('Main/subscribe_users'); ?>
						<input type="text" class="text" placeholder="Email address..." name = "email" required>
					       <input type="submit" value="SUBMIT">
                    <?php echo form_close(); ?>
				</div>
				<div class="col-md-4 help text-right">
					<h3>Are you a farmer?</h3>
					<p>Do you want to sell your products easily?</p>
					<a href="contact.html">CLICK HERE</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="footer-middle">
				<div class="col-md-6 different-products">
					
					<ul>
						<li class="first"> HELP </li> -
						<li><a href=""> FAQ </a></li> |
						<li><a href=""> DELIVERY </a></li> |
						<li><a href=""> PAYMENTS </a></li> |
						<li><a href=""> CANCELLATION & RETURNS </a></li> 
                    </ul>
					<ul>
						<li class="first"> ACCOUNT <li> -
						<li><a href=""> ACCOUNT </a></li> |
						<li><a href=""> MY WISHLIST </a></li> |
						<li><a href=""> MY CART </a></li> 
					</ul>
					<ul>
						<li class="first"> AGROMMERCE </li> -
						<li><a href="contact.html"> CONTACT US </a></li> |
						<li><a href=""> ABOUT US </a></li> |
						<li><a href=""> BLOG </a></li> 
					</ul>
					<ul>
						<li class="first"> POLICIES</li> -
						<li><a href=""> TERMS AND CONDITIONS </a></li> |
						<li><a href=""> PRIVACY POLICY</a></li>
					</ul>
				</div>
				<div class="col-md-6 about-text text-right">
					<h4>About Agrommerce</h4>
					<p>Complimenting and fastracking the agricultural supply chain with technology, we are 	poised to bolster agricultural commerce in Africa and beyond.</p>
				</div>
				<div class="clearfix"></div>
			</div>
		
			<div class="copyright text-center">
				<p>Copyright &copy; 2017 Agrommerce | All rights reserved</p>
			</div>

		</div>
	 </div>
</body>
</html>