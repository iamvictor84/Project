<?php
    defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<!DOCTYPE html>
    <html>
        <head>
            <title>Agrommerce</title>
              <meta name="viewport" content="width=device-width, initial-scale=1">
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                <meta name="keywords" content="Agrommerce an online sourcing platform where agricultural produce can be bought in bulk" />
                <link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
                <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
                <link rel = "icon" href = "<?php echo base_url();?>images/spring.png" type="image/png"/>
                <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css"/>
                <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
            <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
            <link href="<?php echo base_url(); ?>assets/css/megamenu.css" rel="stylesheet" type="text/css" />
            <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/etalage.css">
            <script src="<?php echo base_url(); ?>assets/js/jquery.etalage.min.js"></script>
            <script src="<?php echo base_url(); ?>assets/js/responsiveslides.min.js"></script>
            <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
            <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/megamenu.js"></script>
            <script>$(document).ready(function(){$(".megamenu").megamenu();});</script> 
            <!--<script type = "text/javascript" src = "<?//php echo base_url(); ?>assets/js/jquery.mycart.js"></script>-->

 <script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>
<!--end slider -->
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/flexslider.css" type="text/css"/>
				<script type="text/javascript">
			$(window).load(function() {
				$("#flexiselDemo").flexisel({
					visibleItems: 5,
					animationSpeed: 1000,
					autoPlay: false,
					autoPlaySpeed: 3000,    		
					pauseOnHover: true,
					enableResponsiveBreakpoints: true,
			    	responsiveBreakpoints: { 
			    		portrait: { 
			    			changePoint:480,
			    			visibleItems: 1
			    		}, 
			    		landscape: { 
			    			changePoint:640,
			    			visibleItems: 2
			    		},
			    		tablet: { 
			    			changePoint:768,
			    			visibleItems: 3
			    		}
			    	}
			    });
			    
			});
		</script>
		<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.flexisel.js"></script>
</head>
<body>
	<!-- header-section-starts -->
	<div class="header">
		<div class="top-header">
			<div class="wrap">
				<div class="header-left">
					<ul>
						<li><a href="#">Tel : +234-81-371-712-73</a></li> |
						<li><a href="<?php echo base_url(); ?>order"> Track Your Order</a></li>
					</ul>
				</div>
				<div class="header-right">
					<ul>
						<li>
							<i class="user"></i>
							<a href="account.html">Account</a>
						</li>
						<li>
							<i class="cart"></i>
							<a href="#">Orders</a>
						</li>
                        <li class="last">0</li>	
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="wrap">
			<div class="header-bottom">
				<div class="logo">
					<a href="<?php echo base_url(); ?>home"><img src="<?php echo base_url(); ?>images/new.jpg" class="img-responsive" alt="" /></a>
				</div>
				<div class="search">
					<div class="search2">
					  <?php echo form_open('search/categories'); ?>
						<input type="submit" value="">
						 	<input type="text" placeholder="Search for an item, produce or category" name = "search" required/>
					  <?php echo form_close(); ?>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- header-section-ends -->
	<div class="wrap">
		<div class="navigation-strip">
			<h4>Categories<i class="arrow"></i></h4>
			<div class="top-menu">
				<!-- start header menu -->
		<ul class="megamenu skyblue">
			<li class="grid <?php if($this->uri->uri_string() == 'roots-tubers'){echo 'active';} ?>">
				<a class="color8" href="<?php echo base_url(); ?>roots-tubers">Roots & Tubers</a>
			</li>
			<li class="grid">
				<a class="color8" href="#">Palm Produce</a>
			</li>
			<li class="grid <?php if($this->uri->uri_string() == 'grains-legumes'){echo 'active';} ?>">
				<a class="color8" href="<?php echo base_url(); ?>grains-legumes">Grains & Legumes</a>
			</li>
			<li class="grid">
				<a class="color8" href="#">Livestock</a>
			</li>
			<li class="grid">
				<a class="color8" href="#">Fruits </a>
			</li>
			<li class="grid">
				<a class="color8" href="#">Vegetables</a>
			</li>

				<li><a class="color6" href="#">More</a>
					<div class="megapanel">
					<div class="row">
						<div class="col2">
							<div class="h_nav">
								<h4>Seeds & Nuts</h4>
									<ul>
										<li><a href = "#"> >> View Items</a></li>
									</ul>
							</div>							
						</div>
						<div class="col2">
							<div class="h_nav">
								<h4>Cash Crops</h4>
									<ul>
										<li><a href = "#"> >> View Items</a></li>
									</ul>
							</div>							
						</div>
						<div class="col2">
							<div class="h_nav">
								<h4>Fibers</h4>
									<ul>
										<li><a href = "#"> >> View Items</a></li>
									</ul>
							</div>												
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
		 </ul> 
	</div>
    <div class="clearfix"></div>
</div>
   